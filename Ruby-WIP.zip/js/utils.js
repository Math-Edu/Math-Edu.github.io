//helpers
function home() {
  localStorage.setItem('currentPage', '/');
}
